'use strict'

module.exports = require('bfx-ext-s3-js/workers/loc.api/s3.ext')
