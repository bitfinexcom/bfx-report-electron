'use strict'

module.exports = require('bfx-ext-js/workers/loc.api/sendgrid.ext')
