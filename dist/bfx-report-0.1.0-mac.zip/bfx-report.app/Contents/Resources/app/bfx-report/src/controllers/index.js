'use strict'

const baseController = require('./base.controller')

module.exports = {
  baseController
}
