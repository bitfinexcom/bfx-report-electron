'use strict'

const worker = require('bfx-svc-boot-js')
module.exports = worker
