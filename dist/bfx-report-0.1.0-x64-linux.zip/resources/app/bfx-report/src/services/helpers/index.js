'use strict'

const responses = require('./responses')

module.exports = {
  responses
}
