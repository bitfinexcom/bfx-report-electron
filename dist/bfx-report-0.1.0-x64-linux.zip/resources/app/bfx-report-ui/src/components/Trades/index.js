import Trades from './Trades.container'

export default Trades
