import Orders from './Orders.container'

export default Orders
