import Movements from './Movements.container'

export default Movements
