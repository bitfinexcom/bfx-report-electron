import Timeframe from './Timeframe.container'

export default Timeframe
