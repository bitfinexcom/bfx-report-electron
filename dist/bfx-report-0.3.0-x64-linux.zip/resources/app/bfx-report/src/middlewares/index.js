'use strict'

const headersMiddleware = require('./headers.middleware')

module.exports = {
  headersMiddleware
}
