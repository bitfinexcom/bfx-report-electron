'use strict'

module.exports = require('bfx-ext-js/workers/api.sendgrid.ext.wrk')
