import Auth from './Auth.container'

export default Auth
