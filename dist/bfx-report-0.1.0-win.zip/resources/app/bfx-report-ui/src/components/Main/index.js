import Main from './Main.container'

export default Main
